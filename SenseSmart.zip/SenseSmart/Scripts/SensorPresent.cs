﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
[System.Serializable]
public class Sensor
{
	public Sensor()
	{
		this.entities = new List<Entity>();
		this.attributes = new List<string>();
	}

	[System.Serializable]
	public struct Entity
	{
		public string id;
		public string type;
		public bool isPattern;
	}
	public List<Entity> entities;
	public List<string> attributes;
}

[System.Serializable]
public class SensorDataResponse
{
	public SensorDataResponse()
	{
		this.root = new RootObject ();
	}
	[System.Serializable]
	public class Metadata
	{
		public string name { get; set; }
		public string type { get; set; }
		public string value { get; set; }
	}

	[System.Serializable]
	public class Attribute
	{
		public string name { get; set; }
		public string type { get; set; }
		public string value { get; set; }
		public List<Metadata> metadatas { get; set; }
	}

	[System.Serializable]
	public class ContextElement
	{
		public string type { get; set; }
		public bool isPattern { get; set; }
		public string id { get; set; }
		public List<Attribute> attributes { get; set; }
	}

	[System.Serializable]
	public class StatusCode
	{
		public string code { get; set; }
		public string reasonPhrase { get; set; }
	}
		
	[System.Serializable]
	public class ContextRespons
	{
		public ContextElement contextElement;
		public StatusCode statusCode;
	}

	[System.Serializable]
	public class RootObject
	{
		public List<ContextRespons> contextResponses { get; set; }
	}
	public RootObject root;
}

public class SensorPresent : MonoBehaviour {

	bool dataInvalid;

	Mesh background;
	Material backgroundMat;
	JSONObject lastDataFetch;
	float invalidationTimer;
	float loadTimer;
	int loadFrame;

	public SensorPresent()
	{
		this.dataInvalid = true;
		this.lastDataFetch = null;
		this.invalidationTimer = 0.0f;
		this.loadTimer = 0.0f;
		this.loadFrame = 0;
	}

	// Use this for initialization
	void Start () {
		
	}

	// Update is called once per frame
	void Update () {
		string baseURL = "http://130.240.134.126:1026/v1/queryContext";
		this.invalidationTimer += Time.deltaTime;
		this.loadTimer += Time.deltaTime;

		if (this.invalidationTimer >= 3.0f) {
			this.dataInvalid = true;
			this.invalidationTimer = 0.0f;
		} else if (this.loadTimer >= this.loadFrame + 1) {
			this.loadFrame++;
			if (this.loadFrame > 3) {
				this.loadFrame = 0;
				this.loadTimer = 0.0f;
			}
		}
		if (this.dataInvalid)
		{
			this.StartCoroutine(LoadData(baseURL));
			this.dataInvalid = false;
		}	
			
		TextMesh textMesh = this.GetComponent<TextMesh> ();
		textMesh.text = "<color=\"#C5EFF7\">";
		textMesh.richText = true;

		// update text
		if (this.lastDataFetch != null) {
			for (int i = 0; i < this.lastDataFetch.Count; i++) {
				JSONObject responses = this.lastDataFetch.GetField ("contextResponses");
				for (int j = 0; j < responses.Count; j++) {
					JSONObject response = responses.list [j];
					JSONObject element = response.GetField ("contextElement");
					JSONObject attributes = element.GetField ("attributes");
					textMesh.text += "<b>Id</b>: ";
					textMesh.text += element.GetField ("id").str + "\n\n";
					textMesh.text += "<color=\"#E26A6A\">";
					for (int k = 0; k < attributes.Count; k++) {
						JSONObject attribute = attributes.list [k];
						textMesh.text += "\t\t<b>Name</b>: ";
						textMesh.text += attribute.GetField ("name").str + "\n";
						textMesh.text += "\t\t<b>Value</b>: ";
						textMesh.text += attribute.GetField ("value").str;
						textMesh.text += "\n\n";
					}
					textMesh.text += "</color>";
				}
			}
		} else {
			textMesh.text += "Loading";
			for (int i = 0; i < this.loadFrame; i++) {
				textMesh.text += ".";
			}
		}
		textMesh.text += "</color>";
	}

	IEnumerator LoadData(string url)
	{
		Sensor sensor = new Sensor();
		Sensor.Entity entity = new Sensor.Entity();
		entity.id = "EnvironmentalSensor_S2";
		entity.type = "sensor";
		entity.isPattern = false;
		sensor.entities.Add (entity);
		sensor.attributes.Add ("NH3");
		sensor.attributes.Add ("PM2.5");
		string str = JsonUtility.ToJson (sensor);
		byte[] postData = System.Text.Encoding.UTF8.GetBytes (str);
		Dictionary<string, string> headers = new Dictionary<string, string>();
		headers.Add ("content-type", "application/json");
		WWW request = new WWW (url, postData, headers);

		// wait for response
		yield return request;
		if (request.responseHeaders != null) {
			if (request.responseHeaders.ContainsKey ("STATUS")) {
				// TODO: CHECK STATUS DAMNIT!F
				this.lastDataFetch = new JSONObject (request.text);
			}
		}
	}

	public IEnumerator WaitAndInvalidate()
	{
		yield return new WaitForSeconds (3.0f);
		this.dataInvalid = true;
	}
}
